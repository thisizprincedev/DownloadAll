package cn.sddman.download.mvp.v;

public interface AppSettingView {
    void initSetting(String key,String value);
}
