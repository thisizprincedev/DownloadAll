package cn.sddman.download.mvp.p;

public interface DownloadManagementPresenter {
    void startTask(String url);
}
