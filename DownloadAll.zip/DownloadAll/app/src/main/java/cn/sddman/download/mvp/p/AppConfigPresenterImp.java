package cn.sddman.download.mvp.p;

public class AppConfigPresenterImp implements AppConfigPresenter {

    @Override
    public void getMagnetWebRule() {

    }


}
