package cn.sddman.download.mvp.v;

public interface UrlDownLoadView {
    void addTaskSuccess();
    void addTaskFail(String msg);
}
