package cn.sddman.download.mvp.p;

public interface UrlDownLoadPresenter {
    void startTask(String url);
}
