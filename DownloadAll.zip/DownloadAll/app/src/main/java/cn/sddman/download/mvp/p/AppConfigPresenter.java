package cn.sddman.download.mvp.p;

public interface AppConfigPresenter {
    void getMagnetWebRule();
}
