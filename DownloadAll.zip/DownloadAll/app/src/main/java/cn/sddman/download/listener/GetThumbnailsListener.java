package cn.sddman.download.listener;

import android.graphics.Bitmap;

public interface GetThumbnailsListener {
    void success(Bitmap bitmap);
}
