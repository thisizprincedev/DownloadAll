package com.ess.filepicker.model;

import android.support.v4.content.FileProvider;

/**
 * EssFileProvider
 * Created by 李波 on 2018/2/23.
 */

public class EssFileProvider extends FileProvider {
}
