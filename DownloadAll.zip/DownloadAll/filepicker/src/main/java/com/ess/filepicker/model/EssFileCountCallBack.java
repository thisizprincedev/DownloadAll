package com.ess.filepicker.model;

/**
 * EssFileCountCallBack
 * Created by 李波 on 2018/3/5.
 */

public interface EssFileCountCallBack {
    void onFindChildFileAndFolderCount(int position, String childFileCount, String childFolderCount);
}
